# Groupomania

Groupomania is a social network website for Groupomania employees.
This project is part of my learning journey to become a web developer at **[Openclassrooms](https://openclassrooms.com/en/)**.

The project was created with

- PostgreSQL
- Sequelize
- NodeJS
- Express
- VueJS

I used **Visual Studio Code** for editing.


 The project was tested on the latest versions of **Firefox** and **Google Chrome**.
 Also woking on small displays such as **tablets** and **phones**.
