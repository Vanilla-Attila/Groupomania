<template>
  <div>post</div>
</template>

<script>
export default {};
</script>

<style>
</style>